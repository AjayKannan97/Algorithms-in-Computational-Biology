Algorithms in Computational Biology


1. There are 15 samples provided in the folder 'samples'. Make sure samples and Output folders are created and required samples are placed in the folder.
2. Run - " python Q1.py 0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 " in the terminal for running all the files. 
3. The input will process the number to the 'samples/sample_' + required number.
4. For running independent file - "python Q1.py 5" (change 5 to any number from 0 to 14)
5. The output will be in the output folder provided in the CSE494_598_hw1_kannan. [For ex. Output/sol_5]