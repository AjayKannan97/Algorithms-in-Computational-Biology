CSE 598 - Algo in Computational Biology

Run - "python Q1.py Q2.py Q3.py Q4.py Q5.py Q6.py"

The Submission files are saved in each directory label under Submission/outputs/output_1.txt for every Submission/testcases/test_1.txt.

Q6 - I have done it without suffix array and with Count matrix.
Q2 - I have used blossum matrix for only one of the cases in scoring.